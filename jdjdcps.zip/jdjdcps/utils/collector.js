const cron = require('node-cron');
const JDApi = require('./jdApi');
const { saveOrders } = require('./db');
require('dotenv').config();

class OrderCollector {
    constructor() {
        this.jdApi = new JDApi(
            process.env.JD_APP_KEY,
            process.env.JD_APP_SECRET
        );
        this.isRunning = false;
    }

    // 格式化时间
    formatDateTime(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }

    // 采集订单数据
    async collectOrders() {
        if (this.isRunning) {
            console.log('上一次采集还在进行中，跳过本次采集');
            return;
        }

        this.isRunning = true;
        console.log('开始采集订单数据...');

        try {
            const now = new Date();
            // 采集前2分钟的订单数据
            const endTime = new Date(now.getTime() - 1 * 60 * 1000); // 1分钟前
            const startTime = new Date(endTime.getTime() - 2 * 60 * 1000); // 再往前2分钟

            const startTimeStr = this.formatDateTime(startTime);
            const endTimeStr = this.formatDateTime(endTime);

            console.log(`采集时间范围: ${startTimeStr} ~ ${endTimeStr}`);

            let pageIndex = 1;
            let hasMore = true;
            let totalOrders = 0;

            while (hasMore) {
                const result = await this.jdApi.getOrdersByTimeRange(
                    startTimeStr,
                    endTimeStr,
                    pageIndex,
                    200
                );

                console.log('API返回结果:', JSON.stringify(result, null, 2));

                // 检查返回结果
                if (result.jd_union_open_order_row_query_response) {
                    const response = result.jd_union_open_order_row_query_response;
                    
                    if (response.code === '200' || response.code === 200) {
                        const queryResult = response.queryResult;
                        
                        if (queryResult && queryResult.data && queryResult.data.length > 0) {
                            // 保存订单到数据库
                            const saveResult = await saveOrders(queryResult.data);
                            totalOrders += queryResult.data.length;
                            
                            console.log(`第${pageIndex}页: 新增${saveResult.insertedCount}条, 更新${saveResult.updatedCount}条`);

                            // 检查是否还有更多数据
                            hasMore = queryResult.hasMore || false;
                            pageIndex++;
                        } else {
                            console.log('没有查询到订单数据');
                            hasMore = false;
                        }
                    } else {
                        console.error('API返回错误:', response.zh_desc || response.message);
                        hasMore = false;
                    }
                } else if (result.error_response) {
                    console.error('API错误:', result.error_response);
                    hasMore = false;
                } else {
                    console.error('未知的API返回格式:', result);
                    hasMore = false;
                }
            }

            console.log(`采集完成，共采集${totalOrders}条订单`);
        } catch (error) {
            console.error('采集订单失败:', error);
        } finally {
            this.isRunning = false;
        }
    }

    // 启动定时任务（每分钟执行一次）
    startSchedule() {
        console.log('启动订单采集定时任务，每分钟执行一次');
        
        // 每分钟的第0秒执行
        cron.schedule('0 * * * * *', () => {
            this.collectOrders();
        });

        // 立即执行一次
        this.collectOrders();
    }
}

module.exports = OrderCollector;
