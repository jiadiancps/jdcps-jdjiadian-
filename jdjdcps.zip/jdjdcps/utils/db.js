const mysql = require('mysql2/promise');
require('dotenv').config();

// 创建数据库连接池
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'jd_orders',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// 保存订单到数据库
async function saveOrders(orders) {
    const connection = await pool.getConnection();
    
    try {
        let insertedCount = 0;
        let updatedCount = 0;

        for (const order of orders) {
            const sql = `
                INSERT INTO orders (
                    id, order_id, parent_id, order_time, finish_time, modify_time,
                    order_emt, sku_id, sku_name, sku_num, price, estimate_fee,
                    actual_fee, valid_code, union_id, position_id, cid1, cid2, cid3,
                    cid1_name, cid2_name, cid3_name, shop_name, raw_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    finish_time = VALUES(finish_time),
                    modify_time = VALUES(modify_time),
                    sku_num = VALUES(sku_num),
                    estimate_fee = VALUES(estimate_fee),
                    actual_fee = VALUES(actual_fee),
                    valid_code = VALUES(valid_code),
                    raw_data = VALUES(raw_data),
                    updated_at = CURRENT_TIMESTAMP
            `;

            const values = [
                order.id,
                order.orderId,
                order.parentId || 0,
                order.orderTime,
                order.finishTime,
                order.modifyTime,
                order.orderEmt,
                order.skuId,
                order.skuName,
                order.skuNum,
                order.price,
                order.estimateFee,
                order.actualFee,
                order.validCode,
                order.unionId,
                order.positionId,
                order.cid1,
                order.cid2,
                order.cid3,
                order.categoryInfo?.cid1Name,
                order.categoryInfo?.cid2Name,
                order.categoryInfo?.cid3Name,
                order.goodsInfo?.shopName,
                JSON.stringify(order)
            ];

            const [result] = await connection.execute(sql, values);
            
            if (result.affectedRows === 1) {
                insertedCount++;
            } else if (result.affectedRows === 2) {
                updatedCount++;
            }
        }

        return { insertedCount, updatedCount };
    } finally {
        connection.release();
    }
}

// 查询订单
async function queryOrders(filters = {}, page = 1, pageSize = 20) {
    const connection = await pool.getConnection();
    
    try {
        let whereClauses = [];
        let params = [];

        // 订单号查询
        if (filters.orderId) {
            whereClauses.push('order_id = ?');
            params.push(filters.orderId);
        }

        // 商品名称模糊查询
        if (filters.skuName) {
            whereClauses.push('sku_name LIKE ?');
            params.push(`%${filters.skuName}%`);
        }

        // 时间范围查询
        if (filters.startTime) {
            whereClauses.push('order_time >= ?');
            params.push(filters.startTime);
        }
        if (filters.endTime) {
            whereClauses.push('order_time <= ?');
            params.push(filters.endTime);
        }

        // 有效码筛选
        if (filters.validCode !== undefined) {
            whereClauses.push('valid_code = ?');
            params.push(filters.validCode);
        }

        const whereSQL = whereClauses.length > 0 ? 'WHERE ' + whereClauses.join(' AND ') : '';
        
        // 查询总数
        const countSQL = `SELECT COUNT(*) as total FROM orders ${whereSQL}`;
        const [countResult] = await connection.execute(countSQL, params);
        const total = countResult[0].total;

        // 查询数据
        const offset = (page - 1) * pageSize;
        const dataSQL = `
            SELECT * FROM orders ${whereSQL}
            ORDER BY order_time DESC
            LIMIT ? OFFSET ?
        `;
        const [rows] = await connection.execute(dataSQL, [...params, pageSize, offset]);

        return {
            total,
            page,
            pageSize,
            totalPages: Math.ceil(total / pageSize),
            data: rows
        };
    } finally {
        connection.release();
    }
}

// 获取订单汇总统计
async function getOrderSummary(filters = {}) {
    const connection = await pool.getConnection();
    
    try {
        let whereClauses = [];
        let params = [];

        // 时间范围
        if (filters.startTime) {
            whereClauses.push('order_time >= ?');
            params.push(filters.startTime);
        }
        if (filters.endTime) {
            whereClauses.push('order_time <= ?');
            params.push(filters.endTime);
        }

        const whereSQL = whereClauses.length > 0 ? 'WHERE ' + whereClauses.join(' AND ') : '';

        // 总体统计
        const summarySQL = `
            SELECT 
                COUNT(*) as total_orders,
                SUM(sku_num) as total_items,
                SUM(price * sku_num) as total_amount,
                SUM(estimate_fee) as total_estimate_fee,
                SUM(actual_fee) as total_actual_fee,
                COUNT(DISTINCT order_id) as unique_orders
            FROM orders ${whereSQL}
        `;
        const [summary] = await connection.execute(summarySQL, params);

        // 按日期统计
        const dailySQL = `
            SELECT 
                DATE(order_time) as date,
                COUNT(*) as order_count,
                SUM(estimate_fee) as daily_fee
            FROM orders ${whereSQL}
            GROUP BY DATE(order_time)
            ORDER BY date DESC
            LIMIT 30
        `;
        const [dailyStats] = await connection.execute(dailySQL, params);

        // 按类目统计
        const categorySQL = `
            SELECT 
                cid1_name,
                COUNT(*) as order_count,
                SUM(estimate_fee) as category_fee
            FROM orders ${whereSQL}
            GROUP BY cid1_name
            ORDER BY order_count DESC
            LIMIT 10
        `;
        const [categoryStats] = await connection.execute(categorySQL, params);

        // 按有效码统计
        const validCodeSQL = `
            SELECT 
                valid_code,
                COUNT(*) as count
            FROM orders ${whereSQL}
            GROUP BY valid_code
            ORDER BY count DESC
        `;
        const [validCodeStats] = await connection.execute(validCodeSQL, params);

        return {
            summary: summary[0],
            dailyStats,
            categoryStats,
            validCodeStats
        };
    } finally {
        connection.release();
    }
}

module.exports = {
    pool,
    saveOrders,
    queryOrders,
    getOrderSummary
};
