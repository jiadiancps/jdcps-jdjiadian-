const crypto = require('crypto');
const axios = require('axios');

class JDApi {
    constructor(appKey, appSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;
        this.baseUrl = 'https://api.jd.com/routerjson';
    }

    // 生成签名
    generateSign(params) {
        // 按照参数名的字典序排序
        const sortedKeys = Object.keys(params).sort();
        
        // 拼接参数
        let signStr = this.appSecret;
        sortedKeys.forEach(key => {
            if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
                signStr += key + params[key];
            }
        });
        signStr += this.appSecret;

        // MD5加密并转大写
        return crypto.createHash('md5').update(signStr).digest('hex').toUpperCase();
    }

    // 格式化时间
    formatDateTime(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }

    // 查询订单
    async queryOrders(orderReq) {
        const timestamp = this.formatDateTime(new Date());
        
        // 业务参数
        const paramJson = JSON.stringify({ orderReq });

        // 系统参数
        const params = {
            method: 'jd.union.open.order.row.query',
            app_key: this.appKey,
            timestamp: timestamp,
            format: 'json',
            v: '1.0',
            sign_method: 'md5',
            '360buy_param_json': paramJson
        };

        // 生成签名
        params.sign = this.generateSign(params);

        try {
            const response = await axios.get(this.baseUrl, {
                params: params,
                timeout: 30000
            });

            return response.data;
        } catch (error) {
            console.error('京东API调用失败:', error.message);
            throw error;
        }
    }

    // 获取指定时间范围的订单
    async getOrdersByTimeRange(startTime, endTime, pageIndex = 1, pageSize = 200) {
        const orderReq = {
            pageIndex: pageIndex,
            pageSize: pageSize,
            type: 1, // 按下单时间查询
            startTime: startTime,
            endTime: endTime,
            fields: 'goodsInfo,categoryInfo'
        };

        return await this.queryOrders(orderReq);
    }
}

module.exports = JDApi;
