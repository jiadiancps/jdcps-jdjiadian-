-- 创建数据库
CREATE DATABASE IF NOT EXISTS jdroot DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE jdroot;

-- 创建订单表
CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(255) PRIMARY KEY COMMENT '订单唯一标识',
    order_id BIGINT NOT NULL COMMENT '订单号',
    parent_id BIGINT DEFAULT 0 COMMENT '主单号',
    order_time DATETIME COMMENT '下单时间',
    finish_time DATETIME COMMENT '完成时间',
    modify_time DATETIME COMMENT '更新时间',
    order_emt INT COMMENT '下单设备',
    sku_id BIGINT COMMENT '商品ID',
    sku_name VARCHAR(500) COMMENT '商品名称',
    sku_num INT COMMENT '商品数量',
    price DECIMAL(10,2) COMMENT '商品单价',
    estimate_fee DECIMAL(10,2) COMMENT '预估佣金',
    actual_fee DECIMAL(10,2) COMMENT '实际佣金',
    valid_code INT COMMENT '有效码',
    union_id BIGINT COMMENT '推客ID',
    position_id BIGINT COMMENT '推广位ID',
    cid1 BIGINT COMMENT '一级类目ID',
    cid2 BIGINT COMMENT '二级类目ID',
    cid3 BIGINT COMMENT '三级类目ID',
    cid1_name VARCHAR(100) COMMENT '一级类目名称',
    cid2_name VARCHAR(100) COMMENT '二级类目名称',
    cid3_name VARCHAR(100) COMMENT '三级类目名称',
    shop_name VARCHAR(255) COMMENT '店铺名称',
    raw_data JSON COMMENT '原始数据',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_order_id (order_id),
    INDEX idx_order_time (order_time),
    INDEX idx_valid_code (valid_code),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';
