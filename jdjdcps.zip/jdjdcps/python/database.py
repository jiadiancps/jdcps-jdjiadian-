import pymysql
import json
from typing import List, Dict, Any, Optional
from datetime import datetime
from contextlib import contextmanager


class Database:
    """数据库操作类"""
    
    def __init__(self, host: str, user: str, password: str, database: str):
        self.config = {
            'host': host,
            'user': user,
            'password': password,
            'database': database,
            'charset': 'utf8mb4',
            'cursorclass': pymysql.cursors.DictCursor
        }
    
    @contextmanager
    def get_connection(self):
        """获取数据库连接（上下文管理器）"""
        conn = pymysql.connect(**self.config)
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def save_orders(self, orders: List[Dict[str, Any]]) -> Dict[str, int]:
        """保存订单到数据库"""
        inserted_count = 0
        updated_count = 0
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            for order in orders:
                sql = """
                    INSERT INTO orders (
                        id, order_id, parent_id, order_time, finish_time, modify_time,
                        order_emt, sku_id, sku_name, sku_num, price, estimate_fee,
                        actual_fee, valid_code, union_id, position_id, cid1, cid2, cid3,
                        cid1_name, cid2_name, cid3_name, shop_name, raw_data
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                        %s, %s, %s, %s, %s, %s, %s, %s
                    )
                    ON DUPLICATE KEY UPDATE
                        finish_time = VALUES(finish_time),
                        modify_time = VALUES(modify_time),
                        sku_num = VALUES(sku_num),
                        estimate_fee = VALUES(estimate_fee),
                        actual_fee = VALUES(actual_fee),
                        valid_code = VALUES(valid_code),
                        raw_data = VALUES(raw_data),
                        updated_at = CURRENT_TIMESTAMP
                """
                
                category_info = order.get('categoryInfo', {})
                goods_info = order.get('goodsInfo', {})
                
                values = (
                    order.get('id'),
                    order.get('orderId'),
                    order.get('parentId', 0),
                    order.get('orderTime') or None,
                    order.get('finishTime') or None,
                    order.get('modifyTime') or None,
                    order.get('orderEmt'),
                    order.get('skuId'),
                    order.get('skuName'),
                    order.get('skuNum'),
                    order.get('price'),
                    order.get('estimateFee'),
                    order.get('actualFee'),
                    order.get('validCode'),
                    order.get('unionId'),
                    order.get('positionId'),
                    order.get('cid1'),
                    order.get('cid2'),
                    order.get('cid3'),
                    category_info.get('cid1Name'),
                    category_info.get('cid2Name'),
                    category_info.get('cid3Name'),
                    goods_info.get('shopName'),
                    json.dumps(order, ensure_ascii=False)
                )
                
                cursor.execute(sql, values)
                
                if cursor.rowcount == 1:
                    inserted_count += 1
                elif cursor.rowcount == 2:
                    updated_count += 1
        
        return {'inserted_count': inserted_count, 'updated_count': updated_count}
    
    def query_orders(
        self, 
        filters: Dict[str, Any] = None, 
        page: int = 1, 
        page_size: int = 20
    ) -> Dict[str, Any]:
        """查询订单"""
        filters = filters or {}
        where_clauses = []
        params = []
        
        # 订单号查询
        if filters.get('orderId'):
            where_clauses.append('order_id = %s')
            params.append(filters['orderId'])
        
        # 商品名称模糊查询
        if filters.get('skuName'):
            where_clauses.append('sku_name LIKE %s')
            params.append(f"%{filters['skuName']}%")
        
        # 时间范围查询
        if filters.get('startTime'):
            where_clauses.append('order_time >= %s')
            params.append(filters['startTime'])
        if filters.get('endTime'):
            where_clauses.append('order_time <= %s')
            params.append(filters['endTime'])
        
        # 有效码筛选
        if filters.get('validCode') is not None:
            where_clauses.append('valid_code = %s')
            params.append(filters['validCode'])
        
        where_sql = 'WHERE ' + ' AND '.join(where_clauses) if where_clauses else ''
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 查询总数
            count_sql = f'SELECT COUNT(*) as total FROM orders {where_sql}'
            cursor.execute(count_sql, params)
            total = cursor.fetchone()['total']
            
            # 查询数据
            offset = (page - 1) * page_size
            data_sql = f"""
                SELECT * FROM orders {where_sql}
                ORDER BY order_time DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(data_sql, params + [page_size, offset])
            rows = cursor.fetchall()
        
        return {
            'total': total,
            'page': page,
            'pageSize': page_size,
            'totalPages': (total + page_size - 1) // page_size,
            'data': rows
        }
    
    def get_order_summary(self, filters: Dict[str, Any] = None) -> Dict[str, Any]:
        """获取订单汇总统计"""
        filters = filters or {}
        where_clauses = []
        params = []
        
        # 时间范围
        if filters.get('startTime'):
            where_clauses.append('order_time >= %s')
            params.append(filters['startTime'])
        if filters.get('endTime'):
            where_clauses.append('order_time <= %s')
            params.append(filters['endTime'])
        
        where_sql = 'WHERE ' + ' AND '.join(where_clauses) if where_clauses else ''
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 总体统计
            summary_sql = f"""
                SELECT 
                    COUNT(*) as total_orders,
                    SUM(sku_num) as total_items,
                    SUM(price * sku_num) as total_amount,
                    SUM(estimate_fee) as total_estimate_fee,
                    SUM(actual_fee) as total_actual_fee,
                    COUNT(DISTINCT order_id) as unique_orders
                FROM orders {where_sql}
            """
            cursor.execute(summary_sql, params)
            summary = cursor.fetchone()
            
            # 按日期统计
            daily_sql = f"""
                SELECT 
                    DATE(order_time) as date,
                    COUNT(*) as order_count,
                    SUM(estimate_fee) as daily_fee
                FROM orders {where_sql}
                GROUP BY DATE(order_time)
                ORDER BY date DESC
                LIMIT 30
            """
            cursor.execute(daily_sql, params)
            daily_stats = cursor.fetchall()
            
            # 按类目统计
            category_sql = f"""
                SELECT 
                    cid1_name,
                    COUNT(*) as order_count,
                    SUM(estimate_fee) as category_fee
                FROM orders {where_sql}
                GROUP BY cid1_name
                ORDER BY order_count DESC
                LIMIT 10
            """
            cursor.execute(category_sql, params)
            category_stats = cursor.fetchall()
            
            # 按有效码统计
            valid_code_sql = f"""
                SELECT 
                    valid_code,
                    COUNT(*) as count
                FROM orders {where_sql}
                GROUP BY valid_code
                ORDER BY count DESC
            """
            cursor.execute(valid_code_sql, params)
            valid_code_stats = cursor.fetchall()
        
        return {
            'summary': summary,
            'dailyStats': daily_stats,
            'categoryStats': category_stats,
            'validCodeStats': valid_code_stats
        }
