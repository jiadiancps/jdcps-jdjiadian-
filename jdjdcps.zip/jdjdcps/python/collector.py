import os
import sys
import time
import json
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
from jd_api import JDApi
from database import Database
import threading

# 加载环境变量
load_dotenv()

# 配置日志 - 同时输出到控制台和文件
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'collector.log')

# 创建logger
logger = logging.getLogger('collector')
logger.setLevel(logging.INFO)

# 创建formatter
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

# 文件handler
file_handler = logging.FileHandler(log_file, encoding='utf-8')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)

# 控制台handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)

# 添加handlers
logger.addHandler(file_handler)
logger.addHandler(console_handler)


class OrderCollector:
    """订单采集器 - 支持多账号配置（优化版）"""
    
    # 类级锁，用于数据库写入同步
    db_lock = threading.Lock()
    # API请求限流锁
    api_lock = threading.Lock()
    last_api_call = {}
    
    def __init__(self, account_id: int = 1):
        """
        初始化采集器
        :param account_id: 账号ID，默认1
        """
        self.account_id = account_id
        self.retry_count = 3  # API请求重试次数
        self.retry_delay = 2  # 重试延迟（秒）
        self.api_rate_limit = 1.0  # API请求最小间隔（秒）
        
        # 根据账号ID加载对应的API配置
        app_key_env = f'JD_APP_KEY_{account_id}'
        app_secret_env = f'JD_APP_SECRET_{account_id}'
        
        app_key = os.getenv(app_key_env)
        app_secret = os.getenv(app_secret_env)
        
        if not app_key or not app_secret:
            raise ValueError(f'未找到账号{account_id}的API配置，请检查.env文件中的{app_key_env}和{app_secret_env}')
        
        # 初始化京东API
        self.jd_api = JDApi(
            app_key=app_key,
            app_secret=app_secret
        )
        
        logger.info(f'账号{account_id} - App Key: {app_key[:4]}****{app_key[-4:]}')
        
        # 初始化数据库
        self.db = Database(
            host=os.getenv('DB_HOST', 'localhost'),
            user=os.getenv('DB_USER', 'root'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'jdroot')
        )
        
        self.is_running = False
    
    def format_datetime(self, dt: datetime) -> str:
        """格式化时间"""
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    
    def _wait_for_rate_limit(self):
        """等待限流时间，避免请求过于频繁"""
        with self.api_lock:
            current_time = time.time()
            last_call = self.last_api_call.get(self.account_id, 0)
            time_since_last_call = current_time - last_call
            
            if time_since_last_call < self.api_rate_limit:
                wait_time = self.api_rate_limit - time_since_last_call
                logger.debug(f'账号{self.account_id} - 限流等待 {wait_time:.2f}秒')
                time.sleep(wait_time)
            
            self.last_api_call[self.account_id] = time.time()
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """
        带重试机制的API调用
        :param func: API调用函数
        :return: API返回结果
        """
        for attempt in range(self.retry_count):
            try:
                # 限流控制
                self._wait_for_rate_limit()
                
                # 调用API
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                logger.warning(f'账号{self.account_id} - API调用失败（第{attempt + 1}/{self.retry_count}次）: {e}')
                
                if attempt < self.retry_count - 1:
                    wait_time = self.retry_delay * (attempt + 1)  # 指数退避
                    logger.info(f'账号{self.account_id} - {wait_time}秒后重试...')
                    time.sleep(wait_time)
                else:
                    logger.error(f'账号{self.account_id} - API调用失败，已达到最大重试次数')
                    raise
    
    def collect_orders(self):
        """采集订单数据（优化版）"""
        if self.is_running:
            logger.warning(f'账号{self.account_id} - 上一次采集还在进行中，跳过本次采集')
            return
        
        self.is_running = True
        logger.info('='*60)
        logger.info(f'账号{self.account_id} - 开始采集订单数据...')
        
        try:
            now = datetime.now()
            # 采集前2分钟的订单数据
            end_time = now - timedelta(minutes=1)  # 1分钟前
            start_time = end_time - timedelta(minutes=2)  # 再往前2分钟
            
            start_time_str = self.format_datetime(start_time)
            end_time_str = self.format_datetime(end_time)
            
            logger.info(f'账号{self.account_id} - 采集时间范围: {start_time_str} ~ {end_time_str}')
            
            page_index = 1
            has_more = True
            total_orders = 0
            
            while has_more:
                # 使用带重试的API调用
                result = self._api_call_with_retry(
                    self.jd_api.get_orders_by_time_range,
                    start_time_str,
                    end_time_str,
                    page_index,
                    200
                )
                
                logger.info(f'API返回数据格式正常,开始处理...')
                
                # 检查返回结果 (注意京东API返回的key名称有拼写错误)
                response_key = 'jd_union_open_order_row_query_response'
                if response_key not in result:
                    # 尝试使用拼写错误的key
                    response_key = 'jd_union_open_order_row_query_responce'
                
                if response_key in result:
                    response = result[response_key]
                    
                    if response.get('code') in ['0', 0]:
                        # queryResult是JSON字符串，需要再次解析
                        query_result_str = response.get('queryResult', '{}')
                        if isinstance(query_result_str, str):
                            query_result = json.loads(query_result_str)
                        else:
                            query_result = query_result_str
                        
                        if query_result.get('code') in [200, '200']:
                            if query_result.get('data') and len(query_result['data']) > 0:
                                orders = query_result['data']
                                # 使用锁保护数据库写入
                                try:
                                    with self.db_lock:
                                        save_result = self.db.save_orders(orders)
                                        total_orders += len(orders)
                                        
                                        logger.info(f"账号{self.account_id} - ✓ 第{page_index}页: 新增{save_result['inserted_count']}条, "
                                                  f"更新{save_result['updated_count']}条")
                                except Exception as e:
                                    logger.error(f'✗ 保存订单失败: {e}')
                                
                                # 检查是否还有更多数据
                                has_more = query_result.get('hasMore', False)
                                page_index += 1
                                
                                # 分页请求间隔，避免过于频繁
                                if has_more:
                                    time.sleep(0.5)
                            else:
                                logger.info(f'账号{self.account_id} - 没有查询到订单数据')
                                has_more = False
                        else:
                            logger.error(f"API返回错误: {query_result.get('message')}")
                            has_more = False
                    else:
                        logger.error(f"API返回错误: {response.get('zh_desc') or response.get('message')}")
                        has_more = False
                elif 'error_response' in result:
                    logger.error(f"API错误: {result['error_response']}")
                    has_more = False
                else:
                    logger.error(f'未知的API返回格式: {result}')
                    has_more = False
            
            logger.info(f'账号{self.account_id} - ✓ 采集完成，共采集{total_orders}条订单')
        
        except Exception as e:
            logger.error(f'✗ 采集订单失败: {e}', exc_info=True)
        finally:
            self.is_running = False
    
    def collect_order_by_id(self, order_id: str):
        """根据订单号采集单个订单"""
        logger.info('='*60)
        logger.info(f'账号{self.account_id} - 开始采集订单: {order_id}')
        
        try:
            # 设置查询时间范围：过去30天到现在
            now = datetime.now()
            start_time = now - timedelta(days=30)
            
            order_req = {
                'orderId': int(order_id),
                'pageIndex': 1,
                'pageSize': 10,
                'type': 1,
                'startTime': self.format_datetime(start_time),
                'endTime': self.format_datetime(now)
            }
            
            result = self.jd_api.query_orders(order_req)
            logger.info(f'API返回数据格式正常,开始处理...')
            
            # 检查返回结果
            response_key = 'jd_union_open_order_row_query_response'
            if response_key not in result:
                response_key = 'jd_union_open_order_row_query_responce'
            
            if response_key in result:
                response = result[response_key]
                
                if response.get('code') in ['0', 0]:
                    query_result_str = response.get('queryResult', '{}')
                    if isinstance(query_result_str, str):
                        query_result = json.loads(query_result_str)
                    else:
                        query_result = query_result_str
                    
                    if query_result.get('code') in [200, '200']:
                        if query_result.get('data') and len(query_result['data']) > 0:
                            orders = query_result['data']
                            save_result = self.db.save_orders(orders)
                            logger.info(f"账号{self.account_id} - ✓ 采集成功: 新增{save_result['inserted_count']}条, "
                                      f"更新{save_result['updated_count']}条")
                            return {'success': True, 'data': orders, 'save_result': save_result}
                        else:
                            logger.warning('未找到订单数据')
                            return {'success': False, 'message': '未找到订单数据'}
                    else:
                        error_msg = query_result.get('message', '未知错误')
                        logger.error(f"API返回错误: {error_msg}")
                        return {'success': False, 'message': error_msg}
                else:
                    error_msg = response.get('zh_desc') or response.get('message', '未知错误')
                    logger.error(f"API返回错误: {error_msg}")
                    return {'success': False, 'message': error_msg}
            else:
                logger.error('未知的API返回格式')
                return {'success': False, 'message': '未知的API返回格式'}
                
        except Exception as e:
            logger.error(f'✗ 采集订单失败: {e}', exc_info=True)
            return {'success': False, 'message': str(e)}
    
    def start_schedule_with_offset(self, offset: int = 0):
        """
        启动定时任务（每分钟执行一次，带偏移）
        :param offset: 时间偏移（秒），用于错峰请求
        """
        logger.info('='*60)
        logger.info(f'🚀 账号{self.account_id} - 启动订单采集定时任务，每分钟执行一次')
        logger.info(f'🛡️  优化特性: 错峰{offset}秒 | 限流{self.api_rate_limit}秒 | 重试{self.retry_count}次')
        logger.info('='*60)
        
        # 创建调度器
        scheduler = BackgroundScheduler()
        
        # 根据偏移计算启动秒数
        start_second = offset % 60
        
        # 添加定时任务：每分钟执行一次，但从指定秒数开始
        scheduler.add_job(
            self.collect_orders,
            'cron',
            minute='*',  # 每分钟
            second=str(start_second)  # 指定秒数
        )
        
        # 启动调度器
        scheduler.start()
        
        # 立即执行一次
        self.collect_orders()
        
        try:
            # 保持主线程运行
            while True:
                time.sleep(60)
        except (KeyboardInterrupt, SystemExit):
            logger.info(f'⏹️  账号{self.account_id} - 定时任务已停止')
            scheduler.shutdown()
    
    def start_schedule(self):
        """启动定时任务（每分钟执行一次） - 兼容方法"""
        return self.start_schedule_with_offset(0)

if __name__ == '__main__':
    collector = OrderCollector()
    collector.start_schedule()
