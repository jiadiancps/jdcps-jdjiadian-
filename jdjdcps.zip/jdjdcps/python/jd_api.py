import hashlib
import requests
import json
from datetime import datetime
from typing import Dict, Any, Optional


class JDApi:
    """京东联盟API调用类"""
    
    def __init__(self, app_key: str, app_secret: str):
        self.app_key = app_key
        self.app_secret = app_secret
        self.base_url = 'https://api.jd.com/routerjson'
    
    def generate_sign(self, params: Dict[str, Any]) -> str:
        """生成签名"""
        # 按照参数名的字典序排序
        sorted_keys = sorted(params.keys())
        
        # 拼接参数
        sign_str = self.app_secret
        for key in sorted_keys:
            if params[key] is not None and params[key] != '':
                sign_str += str(key) + str(params[key])
        sign_str += self.app_secret
        
        # MD5加密并转大写
        return hashlib.md5(sign_str.encode('utf-8')).hexdigest().upper()
    
    def format_datetime(self, date: datetime) -> str:
        """格式化时间"""
        return date.strftime('%Y-%m-%d %H:%M:%S')
    
    def query_orders(self, order_req: Dict[str, Any]) -> Dict[str, Any]:
        """查询订单"""
        timestamp = self.format_datetime(datetime.now())
        
        # 业务参数
        param_json = json.dumps({'orderReq': order_req}, ensure_ascii=False)
        
        # 系统参数
        params = {
            'method': 'jd.union.open.order.row.query',
            'app_key': self.app_key,
            'timestamp': timestamp,
            'format': 'json',
            'v': '1.0',
            'sign_method': 'md5',
            '360buy_param_json': param_json
        }
        
        # 生成签名
        params['sign'] = self.generate_sign(params)
        
        try:
            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f'京东API调用失败: {e}')
            raise
    
    def get_orders_by_time_range(
        self, 
        start_time: str, 
        end_time: str, 
        page_index: int = 1, 
        page_size: int = 200
    ) -> Dict[str, Any]:
        """获取指定时间范围的订单"""
        order_req = {
            'pageIndex': page_index,
            'pageSize': page_size,
            'type': 1,  # 按下单时间查询
            'startTime': start_time,
            'endTime': end_time,
            'fields': 'goodsInfo,categoryInfo'
        }
        
        return self.query_orders(order_req)
