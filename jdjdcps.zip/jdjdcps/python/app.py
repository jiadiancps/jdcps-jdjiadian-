import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
from database import Database
from collector import OrderCollector

# 加载环境变量
load_dotenv()

app = Flask(__name__, static_folder='..', static_url_path='')
CORS(app)

# 初始化数据库
db = Database(
    host=os.getenv('DB_HOST', 'localhost'),
    user=os.getenv('DB_USER', 'root'),
    password=os.getenv('DB_PASSWORD', ''),
    database=os.getenv('DB_NAME', 'jdroot')
)

# 初始化采集器
collector = OrderCollector()


@app.route('/')
def index():
    """主页"""
    return send_from_directory('..', 'index.html')


@app.route('/<path:path>')
def static_files(path):
    """静态文件"""
    return send_from_directory('..', path)


@app.route('/api/orders', methods=['GET'])
def query_orders():
    """查询订单"""
    try:
        filters = {
            'orderId': request.args.get('orderId'),
            'skuName': request.args.get('skuName'),
            'startTime': request.args.get('startTime'),
            'endTime': request.args.get('endTime'),
            'validCode': request.args.get('validCode', type=int)
        }
        
        page = request.args.get('page', 1, type=int)
        page_size = request.args.get('pageSize', 20, type=int)
        
        result = db.query_orders(filters, page, page_size)
        
        return jsonify({
            'success': True,
            'data': result
        })
    except Exception as e:
        print(f'查询订单失败: {e}')
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/summary', methods=['GET'])
def get_summary():
    """订单汇总"""
    try:
        filters = {
            'startTime': request.args.get('startTime'),
            'endTime': request.args.get('endTime')
        }
        
        result = db.get_order_summary(filters)
        
        return jsonify({
            'success': True,
            'data': result
        })
    except Exception as e:
        print(f'获取汇总失败: {e}')
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/collect', methods=['POST'])
def collect_order():
    """根据订单号采集订单"""
    try:
        data = request.get_json()
        order_id = data.get('orderId')
        
        if not order_id:
            return jsonify({
                'success': False,
                'message': '请输入订单号'
            }), 400
        
        result = collector.collect_order_by_id(order_id)
        return jsonify(result)
        
    except Exception as e:
        print(f'采集订单失败: {e}')
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    port = int(os.getenv('PORT', 3000))
    print(f'服务器运行在 http://localhost:{port}')
    app.run(host='0.0.0.0', port=port, debug=False)
