#!/usr/bin/env python3
"""
多账号订单采集器
同时运行多个京东联盟API账号进行订单采集
优化版：支持错峰请求、限流控制、错误重试
"""
import os
import sys
import time
import logging
import threading
from datetime import datetime
from dotenv import load_dotenv
from collector import OrderCollector

# 加载环境变量
load_dotenv()

# 配置日志
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'collector_multi.log')

logger = logging.getLogger('collector_multi')
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

file_handler = logging.FileHandler(log_file, encoding='utf-8')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)

logger.addHandler(file_handler)
logger.addHandler(console_handler)


class MultiAccountCollector:
    """多账号采集器管理 - 优化版"""
    
    def __init__(self):
        """初始化多账号采集器"""
        self.collectors = []
        self.threads = []
        self.account_offsets = {}  # 账号采集时间偏移（秒）
        
        # 自动检测可用的账号配置
        self.detect_accounts()
    
    def detect_accounts(self):
        """检测可用的账号配置"""
        logger.info('='*60)
        logger.info('🔍 检测可用的京东联盟API账号配置...')
        logger.info('='*60)
        
        account_id = 1
        while True:
            app_key = os.getenv(f'JD_APP_KEY_{account_id}')
            app_secret = os.getenv(f'JD_APP_SECRET_{account_id}')
            
            if app_key and app_secret:
                logger.info(f'✓ 发现账号{account_id} - App Key: {app_key[:8]}***{app_key[-8:]}')
                try:
                    collector = OrderCollector(account_id=account_id)
                    self.collectors.append(collector)
                    # 为每个账号设置不同的采集时间偏移（错峰请求）
                    # 账号1: 0秒, 账号2: 15秒, 账号3: 30秒, 账号4: 45秒
                    self.account_offsets[account_id] = (account_id - 1) * 15
                    logger.info(f'  采集时间偏移: {self.account_offsets[account_id]}秒（错峰请求）')
                except Exception as e:
                    logger.error(f'✗ 账号{account_id}初始化失败: {e}')
                account_id += 1
            else:
                break
        
        if len(self.collectors) == 0:
            logger.error('❌ 未找到任何可用的账号配置！')
            sys.exit(1)
        
        logger.info('='*60)
        logger.info(f'✅ 共检测到 {len(self.collectors)} 个可用账号')
        logger.info(f'✅ 采用错峰请求策略，每个账号间雔15秒')
        logger.info('='*60)
    
    def run_collector(self, collector: OrderCollector, offset: int):
        """在独立线程中运行采集器"""
        try:
            # 等待偏移时间，实现错峰请求
            if offset > 0:
                logger.info(f'账号{collector.account_id} - 等待{offset}秒后启动（错峰请求）')
                time.sleep(offset)
            
            # 启动带偏移的定时任务
            collector.start_schedule_with_offset(offset)
        except Exception as e:
            logger.error(f'账号{collector.account_id}采集器异常: {e}', exc_info=True)
    
    def start_all(self):
        """启动所有采集器"""
        logger.info('='*60)
        logger.info(f'🚀 启动 {len(self.collectors)} 个账号的采集任务')
        logger.info('🛡️  优化特性：错峰请求 | 限流控制 | 错误重试')
        logger.info('='*60)
        
        # 为每个采集器创建独立线程
        for collector in self.collectors:
            offset = self.account_offsets.get(collector.account_id, 0)
            thread = threading.Thread(
                target=self.run_collector,
                args=(collector, offset),
                name=f'Collector-Account-{collector.account_id}',
                daemon=True
            )
            thread.start()
            self.threads.append(thread)
            logger.info(f'✓ 账号{collector.account_id}采集线程已启动（偏移{offset}秒）')
            time.sleep(0.5)  # 等待线程启动
        
        logger.info('='*60)
        logger.info('✅ 所有采集器已启动，进入运行状态')
        logger.info('='*60)
        
        try:
            # 保持主线程运行
            while True:
                time.sleep(60)
                # 检查线程状态
                alive_count = sum(1 for t in self.threads if t.is_alive())
                if alive_count < len(self.threads):
                    logger.warning(f'⚠️  有 {len(self.threads) - alive_count} 个采集线程已停止')
                    # 可以添加自动重启逻辑
        except (KeyboardInterrupt, SystemExit):
            logger.info('⏹️  收到停止信号，正在关闭所有采集器...')
            for thread in self.threads:
                thread.join(timeout=5)
            logger.info('✓ 所有采集器已停止')


if __name__ == '__main__':
    multi_collector = MultiAccountCollector()
    multi_collector.start_all()
